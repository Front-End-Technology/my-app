import React, { Component } from 'react';


class Topbar extends Component {
  render() {
    return (
      <img src="https://assets.staples-static.com/sbd/cre/products/180715/dg15968/images/dg15968_bts_tophat_crayon_deals_1764x50.jpg"></img>
    );
  }
}

export default Topbar;
