import React, { Component } from 'react';
import Hero from './Hero'
import Navigation from './Navigation'
import Topbar from './Topbar'

class Header extends Component {
  render() {
    return (
    	<div>
	      <Topbar />
	       <Navigation />
	       <Hero />
       </div>
    );
  }
}

export default Header;
