import React, { Component } from 'react';


class Hero extends Component {
  render() {
    return (
      <img class="app-image" src="https://assets.staples-static.com/sbd/cre/products/home-banners/20180715/images/dg16582_c1_hp_ink_offer_1764x262.jpg"></img>
    );
  }
}

export default Hero;
